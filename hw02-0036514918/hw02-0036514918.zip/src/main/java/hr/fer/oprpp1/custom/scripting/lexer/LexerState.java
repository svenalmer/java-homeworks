package hr.fer.oprpp1.custom.scripting.lexer;


/**
 * The Enum LexerState. Contains possible states of the lexer.
 */
public enum LexerState {
	BASIC,
	TAG
}
