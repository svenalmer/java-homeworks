package hr.fer.oprpp1.custom.scripting.nodes;

/**
 * The Class DocumentNode.
 */
public class DocumentNode extends Node {
	
	/**
	 * Instantiates a new document node.
	 */
	public DocumentNode() {}
}
