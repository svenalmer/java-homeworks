package hr.fer.oprpp1.custom.scripting.elems;

/**
 * The Class ElementString.
 */
public class ElementString {
	
}
