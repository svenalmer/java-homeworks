package hr.fer.oprpp1.custom.collections;

public interface Processor {
	
	//public abstract se podrazumijeva!
	void process(Object value);
	
}
