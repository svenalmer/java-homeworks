package hr.fer.oprpp1.hw02.prob1;

public class LexerException extends RuntimeException{
	
	public LexerException(String s) {
		super(s);
	}
}
