package hr.fer.oprpp1.custom.collections;

public interface Processor<T> {
	
	//public abstract se podrazumijeva!
	void process(T value);
	
}
